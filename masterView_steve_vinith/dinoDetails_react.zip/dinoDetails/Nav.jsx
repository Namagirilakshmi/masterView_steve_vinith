import React from 'react';
import ReactDOM from 'react-dom';
import Content from './Content.jsx';

var data=require('json!./assets/object.json');
var dinosaurNames=[];
var index=0;
	for(var key in data) {
    		dinosaurNames.push(key);
	}

class Nav extends React.Component {
	info(e){
		$("nav").addClass("hidden-sm-down");
		$("#content").removeClass("hidden-sm-down");
      	$("button").removeClass("hidden-sm-down");
		ReactDOM.render(<Content speciesName={e.target.innerHTML}/>, document.getElementById('content'));
	}


	render(){
		return(
			<div>
				<nav>
					<li  onClick={this.info}>{dinosaurNames[index++]}</li>
					<li  onClick={this.info}>{dinosaurNames[index++]}</li>
					<li  onClick={this.info}>{dinosaurNames[index++]}</li>
					<li  onClick={this.info}>{dinosaurNames[index++]}</li>
					<li  onClick={this.info}>{dinosaurNames[index++]}</li>
					<li  onClick={this.info}>{dinosaurNames[index++]}</li>
				</nav>
			</div>
			);
	}
}

export default Nav;