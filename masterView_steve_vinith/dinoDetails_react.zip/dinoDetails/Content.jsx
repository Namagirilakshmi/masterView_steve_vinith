import React from 'react';

var data=require('json!./assets/object.json');
class Content extends React.Component {
	render(){
		return(<div>
				<p className="info"> These type of Dinos are believed to be appeared on 
				earth  <span id="appeared">{data[this.props.speciesName].appeared/1000000}</span>m years ago.
				They can grow  upto a height of <span id="height">{data[this.props.speciesName].height}</span> metres.
				Their length was believed to be 
				arround <span id="length">{data[this.props.speciesName].length}</span> metres.</p>

				<p className="detailedInfo">These Dinos belong to the order <span id="order">{data[this.props.speciesName].order}</span>.They vanished 
				around <span id="vanished">{data[this.props.speciesName].vanished/1000000}</span>m years ago.This particular type 
				of dinos weigh around <span id="weight">{data[this.props.speciesName].weight}</span> kg.</p>
			</div>
			)
	}
}
export default Content;