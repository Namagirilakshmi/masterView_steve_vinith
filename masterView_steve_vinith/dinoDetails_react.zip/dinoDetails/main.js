import React from 'react';
import ReactDOM from 'react-dom';
import Nav from './Nav.jsx';

ReactDOM.render(<Nav/>, document.getElementById('navigation'));
