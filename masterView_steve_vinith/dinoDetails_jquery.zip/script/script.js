$(document).ready(function(){
	var count;
	var dinosaurNames=[];
	
	$("#content").hide();
	$.getJSON('assets/object.json', function (data) {
		var count=0;
		for(key in data) {
			$("nav").append("<li class='dinosaur' id="+count+"></li>");
			$("#"+count).text(key);
    		dinosaurNames.push(key);
    		count++;
		}
		$(".dinosaur").click(function(){
			$("#content").show();
			$(".detailedInfo").removeClass("showMore");
			$(".detailedInfo").addClass("showLess");
			$(".more").text("more...");
			
			$("nav").addClass("hidden-sm-down");
			$("#content").removeClass("hidden-sm-down");
    		$("button").removeClass("hidden-sm-down");

			var key=dinosaurNames[$(this).attr('id')];
			var appear=yearConversion(Math.abs(data[key].appeared));
    		$("#appeared").text(appear);
    		$("#height").text(data[key].height);
    		$("#length").text(data[key].length);
    		$("#order").text(data[key].order);
    		var vanish=yearConversion(Math.abs(data[key].vanished));
    		$("#vanished").text(vanish);
    		$("#weight").text(data[key].weight);
    	})
    	function yearConversion(year) {
  			year=year/1000000;
  			return (year+" million");
		}
    	$(".more").click(function(){
   			  if($(".detailedInfo").hasClass("showMore")){
   			  	$(".detailedInfo").removeClass("showMore");
   			  	$(".detailedInfo").addClass("showLess");   			  	
   			  	$(this).text("more...");
   			  }
   			  else{
   			  	$(".detailedInfo").removeClass("showLess");
   			  	$(".detailedInfo").addClass("showMore");
   			  	$(this).text("less...");  
   			  }
		});			
    	$("button").click(function(){
    		$("nav").removeClass("hidden-sm-down");
    		$("#content").addClass("hidden-sm-down");
    		$("button").addClass("hidden-sm-down");
    	})
  	});
})